#!/usr/bin/env python3
"""
Notion集成模块 - 支持与Notion数据库的双向同步
"""

import logging
import json
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
import os

logger = logging.getLogger(__name__)

class NotionIntegration:
    """Notion API集成类"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get('NOTION_API_KEY')
        self.base_url = "https://api.notion.com/v1"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }
    
    def is_configured(self) -> bool:
        """检查Notion是否已配置"""
        return bool(self.api_key)
    
    def create_page(self, database_id: str, title: str, content: str, 
                   properties: Dict = None) -> Optional[Dict]:
        """在Notion中创建新页面"""
        if not self.is_configured():
            logger.warning("Notion API密钥未配置")
            return None
        
        try:
            page_data = {
                "parent": {"database_id": database_id},
                "properties": {
                    "Name": {
                        "title": [
                            {
                                "text": {
                                    "content": title
                                }
                            }
                        ]
                    }
                },
                "children": [
                    {
                        "object": "block",
                        "type": "paragraph",
                        "paragraph": {
                            "rich_text": [
                                {
                                    "type": "text",
                                    "text": {
                                        "content": content
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
            
            # 添加自定义属性
            if properties:
                page_data["properties"].update(properties)
            
            response = requests.post(
                f"{self.base_url}/pages",
                headers=self.headers,
                json=page_data,
                timeout=30
            )
            
            response.raise_for_status()
            result = response.json()
            logger.info(f"Notion页面创建成功: {title}")
            return result
            
        except Exception as e:
            logger.error(f"Notion页面创建失败: {e}")
            return None
    
    def query_database(self, database_id: str, filter_conditions: Dict = None, 
                      sort: List[Dict] = None) -> List[Dict]:
        """查询Notion数据库"""
        if not self.is_configured():
            logger.warning("Notion API密钥未配置")
            return []
        
        try:
            query_data = {}
            if filter_conditions:
                query_data["filter"] = filter_conditions
            if sort:
                query_data["sorts"] = sort
            
            response = requests.post(
                f"{self.base_url}/databases/{database_id}/query",
                headers=self.headers,
                json=query_data,
                timeout=30
            )
            
            response.raise_for_status()
            results = response.json().get('results', [])
            
            parsed_results = []
            for item in results:
                parsed_results.append(self._parse_page(item))
            
            logger.info(f"Notion数据库查询成功，找到 {len(parsed_results)} 条记录")
            return parsed_results
            
        except Exception as e:
            logger.error(f"Notion数据库查询失败: {e}")
            return []
    
    def _parse_page(self, page_data: Dict) -> Dict:
        """解析Notion页面数据"""
        try:
            properties = page_data.get('properties', {})
            title = ""
            
            # 提取标题
            if 'Name' in properties and properties['Name'].get('title'):
                title = properties['Name']['title'][0]['text']['content']
            elif 'Title' in properties and properties['Title'].get('title'):
                title = properties['Title']['title'][0]['text']['content']
            
            # 提取内容（需要额外API调用）
            content = self._extract_page_content(page_data['id'])
            
            return {
                'id': page_data['id'],
                'title': title,
                'url': page_data.get('url', ''),
                'created_time': page_data.get('created_time', ''),
                'last_edited_time': page_data.get('last_edited_time', ''),
                'content': content,
                'properties': properties
            }
            
        except Exception as e:
            logger.error(f"Notion页面解析失败: {e}")
            return {}
    
    def _extract_page_content(self, page_id: str) -> str:
        """提取页面内容"""
        try:
            response = requests.get(
                f"{self.base_url}/blocks/{page_id}/children",
                headers=self.headers,
                timeout=30
            )
            
            response.raise_for_status()
            blocks = response.json().get('results', [])
            
            content_lines = []
            for block in blocks:
                if block.get('type') == 'paragraph' and block['paragraph'].get('rich_text'):
                    for text in block['paragraph']['rich_text']:
                        if text.get('text'):
                            content_lines.append(text['text']['content'])
                elif block.get('type') == 'heading_1' and block['heading_1'].get('rich_text'):
                    for text in block['heading_1']['rich_text']:
                        if text.get('text'):
                            content_lines.append(f"# {text['text']['content']}")
                elif block.get('type') == 'heading_2' and block['heading_2'].get('rich_text'):
                    for text in block['heading_2']['rich_text']:
                        if text.get('text'):
                            content_lines.append(f"## {text['text']['content']}")
            
            return '\n'.join(content_lines)
            
        except Exception as e:
            logger.error(f"Notion页面内容提取失败: {e}")
            return ""
    
    def sync_to_notion(self, database_id: str, knowledge_data: List[Dict]) -> int:
        """同步知识到Notion"""
        if not self.is_configured():
            logger.warning("Notion API密钥未配置")
            return 0
        
        synced_count = 0
        
        for item in knowledge_data:
            try:
                # 检查是否已存在（基于标题）
                existing = self.query_database(
                    database_id,
                    {
                        "property": "Name",
                        "title": {
                            "equals": item['topic']
                        }
                    }
                )
                
                if not existing:  # 不存在则创建
                    self.create_page(
                        database_id,
                        item['topic'],
                        item['content'],
                        {
                            "Source": {
                                "rich_text": [{
                                    "text": {"content": item.get('source', 'learning_agent')}
                                }]
                            },
                            "Created": {
                                "date": {"start": item.get('created_at', datetime.now().isoformat())}
                            }
                        }
                    )
                    synced_count += 1
                    
            except Exception as e:
                logger.error(f"同步到Notion失败: {e}")
        
        logger.info(f"成功同步 {synced_count} 条知识到Notion")
        return synced_count
    
    def sync_from_notion(self, database_id: str) -> List[Dict]:
        """从Notion同步知识"""
        if not self.is_configured():
            logger.warning("Notion API密钥未配置")
            return []
        
        try:
            pages = self.query_database(database_id)
            
            knowledge_items = []
            for page in pages:
                if page['title'] and page['content']:
                    knowledge_items.append({
                        'topic': page['title'],
                        'content': page['content'],
                        'source': f"notion:{database_id}",
                        'created_at': page.get('created_time', '')
                    })
            
            logger.info(f"从Notion同步了 {len(knowledge_items)} 条知识")
            return knowledge_items
            
        except Exception as e:
            logger.error(f"从Notion同步失败: {e}")
            return []

def main():
    """测试Notion集成"""
    notion = NotionIntegration()
    
    if notion.is_configured():
        print("✅ Notion集成已配置")
        
        # 示例：查询数据库
        # database_id = "your_database_id_here"
        # results = notion.query_database(database_id)
        # print(f"找到 {len(results)} 个页面")
        
    else:
        print("❌ Notion API密钥未配置")
        print("请设置环境变量 NOTION_API_KEY 或在代码中提供API密钥")

if __name__ == "__main__":
    main()