#!/usr/bin/env python3
"""
MCP (Model Context Protocol) 工具集成模块
支持各种开源软件的集成
"""

import logging
import json
import requests
from typing import Dict, List, Optional, Any
import subprocess
import os

logger = logging.getLogger(__name__)

class MCPIntegration:
    """MCP工具集成管理器"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.available_tools = self._discover_tools()
    
    def _discover_tools(self) -> Dict[str, Dict]:
        """发现可用的MCP工具"""
        # 从配置数组中提取工具状态
        tool_configs = {}
        for tool_config in self.config:
            tool_configs[tool_config['name']] = tool_config
        
        tools = {
            'web_search': {
                'name': 'Web搜索',
                'description': '互联网内容搜索工具',
                'enabled': tool_configs.get('web_search', {}).get('enabled', False),
                'function': self.web_search
            },
            'file_processor': {
                'name': '文件处理',
                'description': '文档和文件内容提取工具',
                'enabled': tool_configs.get('file_processing', {}).get('enabled', False),
                'function': self.process_file
            },
            'code_analyzer': {
                'name': '代码分析',
                'description': '源代码分析和理解工具',
                'enabled': tool_configs.get('code_analysis', {}).get('enabled', False),
                'function': self.analyze_code
            },
            'knowledge_graph': {
                'name': '知识图谱',
                'description': '知识关系构建和查询工具',
                'enabled': True,  # 默认启用
                'function': self.build_knowledge_graph
            }
        }
        return tools
    
    def web_search(self, query: str, max_results: int = 5) -> List[Dict]:
        """执行Web搜索"""
        try:
            # 使用DuckDuckGo API进行搜索
            url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1&skip_disambig=1"
            
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            results = []
            
            # 提取抽象文本
            if data.get('AbstractText'):
                results.append({
                    'title': data.get('Heading', '摘要'),
                    'content': data['AbstractText'],
                    'source': 'DuckDuckGo',
                    'url': data.get('AbstractURL', '')
                })
            
            # 提取相关主题
            for topic in data.get('RelatedTopics', [])[:max_results]:
                if 'Text' in topic:
                    results.append({
                        'title': topic.get('FirstURL', '').split('/')[-1].replace('_', ' '),
                        'content': topic['Text'],
                        'source': 'DuckDuckGo',
                        'url': topic.get('FirstURL', '')
                    })
            
            logger.info(f"Web搜索完成: {query}, 找到 {len(results)} 个结果")
            return results
            
        except Exception as e:
            logger.error(f"Web搜索失败: {e}")
            return []
    
    def process_file(self, file_path: str) -> Optional[str]:
        """处理各种格式的文件并提取文本内容"""
        try:
            if not os.path.exists(file_path):
                logger.error(f"文件不存在: {file_path}")
                return None
            
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext == '.txt':
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            
            elif file_ext == '.pdf':
                # 使用PyPDF2处理PDF文件
                try:
                    import PyPDF2
                    with open(file_path, 'rb') as f:
                        pdf_reader = PyPDF2.PdfReader(f)
                        text = ''
                        for page in pdf_reader.pages:
                            text += page.extract_text() + '\n'
                        return text
                except ImportError:
                    logger.warning("PyPDF2未安装，无法处理PDF文件")
                    return None
            
            elif file_ext in ['.doc', '.docx']:
                # 处理Word文档
                try:
                    from docx import Document
                    doc = Document(file_path)
                    text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
                    return text
                except ImportError:
                    logger.warning("python-docx未安装，无法处理Word文档")
                    return None
            
            elif file_ext in ['.pptx']:
                # 处理PowerPoint文档
                try:
                    from pptx import Presentation
                    prs = Presentation(file_path)
                    text = ''
                    for slide in prs.slides:
                        for shape in slide.shapes:
                            if hasattr(shape, 'text'):
                                text += shape.text + '\n'
                    return text
                except ImportError:
                    logger.warning("python-pptx未安装，无法处理PPT文档")
                    return None
            
            elif file_ext == '.md':
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            
            else:
                logger.warning(f"不支持的文件格式: {file_ext}")
                return None
                
        except Exception as e:
            logger.error(f"文件处理失败: {e}")
            return None
    
    def analyze_code(self, code: str, language: str = 'python') -> Dict:
        """分析代码并提供理解"""
        try:
            analysis = {
                'language': language,
                'size': len(code),
                'lines': code.count('\n') + 1,
                'complexity': self._estimate_complexity(code, language),
                'key_functions': self._extract_functions(code, language),
                'dependencies': self._find_dependencies(code, language),
                'suggestions': []
            }
            
            # 添加基本建议
            if analysis['lines'] > 100:
                analysis['suggestions'].append("代码较长，考虑模块化重构")
            
            if analysis['complexity'] == 'high':
                analysis['suggestions'].append("代码复杂度较高，建议简化逻辑")
            
            logger.info(f"代码分析完成: {language}, {analysis['lines']} 行")
            return analysis
            
        except Exception as e:
            logger.error(f"代码分析失败: {e}")
            return {'error': str(e)}
    
    def _estimate_complexity(self, code: str, language: str) -> str:
        """估计代码复杂度"""
        # 简单的复杂度估计
        lines = code.count('\n') + 1
        
        if lines <= 50:
            return 'low'
        elif lines <= 200:
            return 'medium'
        else:
            return 'high'
    
    def _extract_functions(self, code: str, language: str) -> List[str]:
        """提取函数信息"""
        functions = []
        
        if language == 'python':
            lines = code.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('def '):
                    func_name = line[4:].split('(')[0].strip()
                    functions.append(func_name)
        
        return functions
    
    def _find_dependencies(self, code: str, language: str) -> List[str]:
        """查找依赖关系"""
        dependencies = []
        
        if language == 'python':
            lines = code.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('import '):
                    dep = line[7:].split()[0]
                    dependencies.append(dep)
                elif line.startswith('from '):
                    parts = line[5:].split(' import ')
                    if len(parts) == 2:
                        dependencies.append(parts[0].strip())
        
        return dependencies
    
    def build_knowledge_graph(self, content: str) -> Dict:
        """构建知识图谱"""
        try:
            # 简单的实体和关系提取
            lines = content.split('\n')
            entities = set()
            relationships = []
            
            for line in lines:
                words = line.split()
                if len(words) >= 3:
                    # 简单的实体识别（大写字母开头的单词）
                    potential_entities = [word for word in words if word[0].isupper()]
                    entities.update(potential_entities)
                    
                    # 简单的关系提取
                    if '是' in line or '属于' in line or '包含' in line:
                        relationships.append(line)
            
            return {
                'entities': list(entities),
                'relationships': relationships,
                'entity_count': len(entities),
                'relationship_count': len(relationships)
            }
            
        except Exception as e:
            logger.error(f"知识图谱构建失败: {e}")
            return {'error': str(e)}
    
    def get_available_tools(self) -> List[Dict]:
        """获取可用的工具列表"""
        return [
            {
                'name': tool_info['name'],
                'description': tool_info['description'],
                'enabled': tool_info['enabled']
            }
            for tool_name, tool_info in self.available_tools.items()
        ]
    
    def execute_tool(self, tool_name: str, **kwargs) -> Any:
        """执行指定的工具"""
        if tool_name not in self.available_tools:
            logger.error(f"工具不存在: {tool_name}")
            return None
        
        tool = self.available_tools[tool_name]
        if not tool['enabled']:
            logger.warning(f"工具未启用: {tool_name}")
            return None
        
        try:
            return tool['function'](**kwargs)
        except Exception as e:
            logger.error(f"工具执行失败 {tool_name}: {e}")
            return None

def main():
    """测试MCP集成"""
    config = {
        'web_search': {'enabled': True},
        'file_processing': {'enabled': True},
        'code_analysis': {'enabled': True}
    }
    
    mcp = MCPIntegration(config)
    
    # 测试Web搜索
    print("测试Web搜索...")
    results = mcp.web_search("Python编程")
    for result in results:
        print(f"- {result['title']}: {result['content'][:100]}...")
    
    # 测试可用工具
    print("\n可用工具:")
    for tool in mcp.get_available_tools():
        status = "启用" if tool['enabled'] else "禁用"
        print(f"- {tool['name']} ({status}): {tool['description']}")

if __name__ == "__main__":
    main()