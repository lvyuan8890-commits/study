#!/usr/bin/env python3
"""
增强版学习智能体 - 集成MCP工具的高级版本
"""

import os
import json
import logging
import sqlite3
from datetime import datetime
from typing import Dict, List, Optional, Any
from main import LearningAgent
from mcp_integration import MCPIntegration
from notion_integration import NotionIntegration
from web_crawler import WebCrawler

logger = logging.getLogger(__name__)

class EnhancedLearningAgent(LearningAgent):
    """增强版学习智能体，集成MCP工具"""
    
    def __init__(self, db_path: str = "knowledge_base.db", config_path: str = "config.json"):
        super().__init__(db_path)
        self.config = self._load_config(config_path)
        self.mcp = MCPIntegration(self.config.get('mcp_integration', {}).get('tools', {}))
        self.notion = NotionIntegration(self.config.get('notion', {}).get('api_key'))
        self.web_crawler = WebCrawler(self.config.get('web_crawler', {}))
        self._setup_mcp_tools()
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        default_config = {
            'learning_agent': {
                'database_path': 'knowledge_base.db',
                'log_level': 'INFO',
                'max_search_results': 10
            },
            'mcp_integration': {
                'tools': {
                    'web_search': {'enabled': True},
                    'file_processing': {'enabled': True},
                    'code_analysis': {'enabled': True}
                }
            },
            'notion': {
                'api_key': None,
                'default_database': None
            },
            'web_crawler': {
                'max_depth': 2,
                'delay': 1.0,
                'max_pages': 50,
                'auto_crawl': False
            }
        }
        
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"配置文件加载失败，使用默认配置: {e}")
                return default_config
        else:
            logger.info("配置文件不存在，使用默认配置")
            return default_config
    
    def _setup_mcp_tools(self):
        """设置MCP工具"""
        logger.info("初始化MCP工具...")
        
        # 注册MCP工具到智能体
        for tool_name, tool_info in self.mcp.available_tools.items():
            if tool_info['enabled']:
                self.integrate_mcp_tool(tool_name, tool_info)
                logger.info(f"MCP工具已注册: {tool_name}")
    
    def learn_from_web(self, query: str, max_results: int = 3) -> bool:
        """从Web学习知识"""
        try:
            results = self.mcp.web_search(query, max_results)
            
            learned_count = 0
            for result in results:
                topic = result['title']
                content = f"{result['content']}\n\n来源: {result.get('url', '未知')}"
                
                if self.learn_knowledge(topic, content, f"web_search:{query}"):
                    learned_count += 1
            
            logger.info(f"从Web学习了 {learned_count} 条关于 '{query}' 的知识")
            return learned_count > 0
            
        except Exception as e:
            logger.error(f"从Web学习失败: {e}")
            return False
    
    def learn_from_file(self, file_path: str) -> bool:
        """从文件学习知识"""
        try:
            content = self.mcp.process_file(file_path)
            if not content:
                return False
            
            # 使用文件名作为主题
            topic = os.path.basename(file_path)
            
            # 构建知识图谱获取关键信息
            knowledge_graph = self.mcp.build_knowledge_graph(content)
            
            # 创建丰富的知识内容
            knowledge_content = f"""文件内容摘要:
{content[:500]}...

关键实体: {', '.join(knowledge_graph.get('entities', [])[:5])}

关系分析: {len(knowledge_graph.get('relationships', []))} 个关系被发现

原始文件: {file_path}"""
            
            if self.learn_knowledge(topic, knowledge_content, f"file:{file_path}"):
                logger.info(f"从文件学习了知识: {topic}")
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"从文件学习失败: {e}")
            return False
    
    def enhanced_answer_question(self, question: str, use_web: bool = True) -> str:
        """增强版回答问题，可结合Web搜索"""
        # 首先尝试从本地知识库回答
        local_answer = self.answer_question(question)
        
        if local_answer and len(local_answer) > 50:  # 如果有足够详细的本地答案
            return local_answer
        
        # 如果本地知识不足且允许Web搜索
        if use_web and self.mcp.available_tools['web_search']['enabled']:
            logger.info(f"本地知识不足，尝试Web搜索: {question}")
            
            web_results = self.mcp.web_search(question, max_results=2)
            if web_results:
                # 从Web结果构建答案
                answer_parts = ["根据最新信息:"]
                
                for result in web_results:
                    answer_parts.append(f"• {result['title']}: {result['content']}")
                    
                    # 同时学习这个新知识
                    self.learn_knowledge(
                        result['title'], 
                        result['content'], 
                        f"web_search:{question}"
                    )
                
                answer_parts.append("\n(以上信息来自互联网搜索)")
                return "\n".join(answer_parts)
            
            return "抱歉，我无法找到相关信息。您可以尝试教我这方面的知识。"
        
        return local_answer or "抱歉，我还没有学习过这方面的知识。"
    
    def analyze_and_learn_code(self, code: str, language: str = 'python') -> Dict:
        """分析代码并学习相关知识"""
        try:
            analysis = self.mcp.analyze_code(code, language)
            
            # 创建代码知识主题
            topic = f"{language}代码分析 - {datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # 构建知识内容
            content = f"""代码分析报告:
语言: {analysis['language']}
大小: {analysis['size']} 字符, {analysis['lines']} 行
复杂度: {analysis['complexity']}

主要函数: {', '.join(analysis['key_functions'][:5])}

依赖: {', '.join(analysis['dependencies'][:5])}

建议:
{chr(10).join(analysis['suggestions'])}

原始代码:
{code[:1000]}{'...' if len(code) > 1000 else ''}"""
            
            if self.learn_knowledge(topic, content, "code_analysis"):
                logger.info(f"代码分析完成并已学习: {topic}")
                analysis['learned'] = True
                analysis['knowledge_topic'] = topic
            else:
                analysis['learned'] = False
            
            return analysis
            
        except Exception as e:
            logger.error(f"代码分析学习失败: {e}")
            return {'error': str(e), 'learned': False}
    
    def sync_to_notion(self, database_id: str = None) -> Dict:
        """同步知识到Notion"""
        try:
            if not self.notion.is_configured():
                return {'success': False, 'message': 'Notion API密钥未配置'}
            
            database_id = database_id or self.config.get('notion', {}).get('default_database')
            if not database_id:
                return {'success': False, 'message': '未指定Notion数据库ID'}
            
            # 获取所有知识
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('SELECT topic, content, source, created_at FROM knowledge')
            
            knowledge_data = []
            for row in cursor.fetchall():
                knowledge_data.append({
                    'topic': row[0],
                    'content': row[1],
                    'source': row[2],
                    'created_at': row[3]
                })
            
            conn.close()
            
            # 同步到Notion
            synced_count = self.notion.sync_to_notion(database_id, knowledge_data)
            
            return {
                'success': True,
                'synced_count': synced_count,
                'total_count': len(knowledge_data),
                'message': f'成功同步 {synced_count}/{len(knowledge_data)} 条知识到Notion'
            }
            
        except Exception as e:
            logger.error(f"同步到Notion失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def sync_from_notion(self, database_id: str = None) -> Dict:
        """从Notion同步知识"""
        try:
            if not self.notion.is_configured():
                return {'success': False, 'message': 'Notion API密钥未配置'}
            
            database_id = database_id or self.config.get('notion', {}).get('default_database')
            if not database_id:
                return {'success': False, 'message': '未指定Notion数据库ID'}
            
            # 从Notion获取知识
            knowledge_items = self.notion.sync_from_notion(database_id)
            
            learned_count = 0
            for item in knowledge_items:
                if self.learn_knowledge(item['topic'], item['content'], item['source']):
                    learned_count += 1
            
            return {
                'success': True,
                'learned_count': learned_count,
                'total_count': len(knowledge_items),
                'message': f'从Notion学习了 {learned_count}/{len(knowledge_items)} 条知识'
            }
            
        except Exception as e:
            logger.error(f"从Notion同步失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def crawl_website(self, url: str, max_pages: int = 10) -> Dict:
        """爬取网站内容并学习"""
        try:
            results = self.web_crawler.crawl_website(url, max_pages)
            
            learned_count = 0
            for page in results:
                topic = f"网页抓取: {page['title']}"
                content = f"""来源URL: {page['url']}
抓取时间: {page['timestamp']}

页面内容:
{page['content'][:2000]}

元数据: {json.dumps(page['metadata'], ensure_ascii=False)}"""
                
                if self.learn_knowledge(topic, content, f"web_crawl:{url}"):
                    learned_count += 1
            
            return {
                'success': True,
                'learned_count': learned_count,
                'total_pages': len(results),
                'message': f'从网站爬取并学习了 {learned_count}/{len(results)} 个页面'
            }
            
        except Exception as e:
            logger.error(f"网站爬取失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def search_and_learn(self, query: str, max_results: int = 5, search_engine: str = 'google') -> Dict:
        """搜索并学习网络内容"""
        try:
            results = self.web_crawler.search_and_crawl(query, search_engine, max_results)
            
            learned_count = 0
            for page in results:
                topic = f"网络搜索: {page['title']} - {query}"
                content = f"""搜索关键词: {query}
搜索引擎: {search_engine}
来源URL: {page['url']}
抓取时间: {page['timestamp']}

内容摘要:
{page['content'][:2000]}

元数据: {json.dumps(page['metadata'], ensure_ascii=False, indent=2)}"""
                
                if self.learn_knowledge(topic, content, f"web_search:{search_engine}:{query}"):
                    learned_count += 1
            
            return {
                'success': True,
                'learned_count': learned_count,
                'total_results': len(results),
                'search_engine': search_engine,
                'query': query,
                'message': f'使用 {search_engine} 搜索并学习了 {learned_count}/{len(results)} 条关于 "{query}" 的结果'
            }
            
        except Exception as e:
            logger.error(f"搜索学习失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def generate_personalized_learning(self, interests: List[str], max_topics: int = 3) -> Dict:
        """根据用户兴趣生成个性化学习内容"""
        try:
            learning_results = []
            
            for interest in interests[:max_topics]:
                # 生成相关的搜索查询
                search_queries = [
                    f"{interest} 入门教程",
                    f"{interest} 基础知识",
                    f"学习 {interest} 的最佳实践",
                    f"{interest} 常见问题解答",
                    f"{interest} 最新发展"
                ]
                
                for query in search_queries:
                    result = self.search_and_learn(query, 2, 'google')
                    if result['success']:
                        learning_results.append({
                            'interest': interest,
                            'query': query,
                            'learned_count': result['learned_count'],
                            'message': result['message']
                        })
                    
                    # 稍微延迟以避免请求过于频繁
                    time.sleep(1)
            
            return {
                'success': True,
                'total_interests': len(interests),
                'processed_interests': min(len(interests), max_topics),
                'learning_results': learning_results,
                'message': f'已为 {len(interests)} 个兴趣生成个性化学习内容'
            }
            
        except Exception as e:
            logger.error(f"生成个性化学习内容失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_learning_stats(self) -> Dict:
        """获取学习统计信息"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 知识数量
            cursor.execute('SELECT COUNT(*) FROM knowledge')
            knowledge_count = cursor.fetchone()[0]
            
            # 问答对数量
            cursor.execute('SELECT COUNT(*) FROM qa_pairs')
            qa_count = cursor.fetchone()[0]
            
            # 主题数量
            cursor.execute('SELECT COUNT(DISTINCT topic) FROM knowledge')
            topic_count = cursor.fetchone()[0]
            
            # 最新学习时间
            cursor.execute('SELECT MAX(created_at) FROM knowledge')
            last_learned = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'knowledge_count': knowledge_count,
                'qa_count': qa_count,
                'topic_count': topic_count,
                'last_learned': last_learned,
                'mcp_tools_enabled': sum(1 for tool in self.mcp.get_available_tools() if tool['enabled']),
                'notion_configured': self.notion.is_configured(),
                'web_crawler_ready': True
            }
            
        except Exception as e:
            logger.error(f"获取学习统计失败: {e}")
            return {'error': str(e)}

def interactive_enhanced_agent():
    """增强版交互式智能体"""
    agent = EnhancedLearningAgent()
    
    print("🚀 增强版学习智能体已启动！")
    print("📊 系统统计:")
    stats = agent.get_learning_stats()
    if 'error' in stats:
        print(f"  统计信息获取失败: {stats['error']}")
    else:
        print(f"  知识条目: {stats['knowledge_count']}")
        print(f"  问答对: {stats['qa_count']}")
        print(f"  主题数量: {stats['topic_count']}")
        print(f"  MCP工具: {stats['mcp_tools_enabled']} 个已启用")
    print("\n💡 可用命令:")
    print("  learn 主题:内容       - 学习新知识")
    print("  web 搜索词           - 从Web学习")
    print("  file 文件路径        - 从文件学习")
    print("  ask 问题             - 提问问题")
    print("  search 关键词        - 搜索知识")
    print("  analyze 代码         - 分析代码")
    print("  search_learn <query> [max_results] [engine] - 搜索并学习网络内容")
    print("  personalized_learn <兴趣1,兴趣2,...> [max_topics] - 个性化学习内容生成")
    print("  stats                - 查看统计")
    print("  topics               - 列出主题")
    print("  tools                - 查看工具")
    print("  quit                 - 退出")
    
    while True:
        try:
            user_input = input("\n🤖 > ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("👋 再见！")
                break
            
            elif user_input.lower() in ['help', '?']:
                print("💡 可用命令:")
                print("  learn 主题:内容       - 学习新知识")
                print("  web 搜索词           - 从Web学习")
                print("  file 文件路径        - 从文件学习")
                print("  ask 问题             - 提问问题")
                print("  search 关键词        - 搜索知识")
                print("  analyze 代码         - 分析代码")
                print("  notion_sync [to|from] - 与Notion双向同步")
                print("  crawl <url> [max_pages] - 爬取网站内容")
                print("  search_learn <query> [max_results] [engine] - 搜索并学习网络内容")
                print("  personalized_learn <兴趣1,兴趣2,...> [max_topics] - 个性化学习内容生成")
                print("  stats                - 查看统计")
                print("  topics               - 列出主题")
                print("  tools                - 查看工具")
                print("  quit                 - 退出")
            
            elif user_input.startswith('learn '):
                parts = user_input[6:].split(':', 1)
                if len(parts) == 2:
                    agent.learn_knowledge(parts[0].strip(), parts[1].strip())
                    print("✅ 学习完成！")
                else:
                    print("❌ 格式错误，请使用: learn 主题:内容")
            
            elif user_input.startswith('web '):
                query = user_input[4:]
                if agent.learn_from_web(query):
                    print(f"✅ 已从Web学习关于 '{query}' 的知识")
                else:
                    print("❌ Web学习失败")
            
            elif user_input.startswith('file '):
                file_path = user_input[5:]
                if os.path.exists(file_path):
                    if agent.learn_from_file(file_path):
                        print(f"✅ 已从文件学习: {file_path}")
                    else:
                        print("❌ 文件学习失败")
                else:
                    print("❌ 文件不存在")
            
            elif user_input.startswith('ask '):
                question = user_input[4:]
                answer = agent.enhanced_answer_question(question)
                print(f"\n📝 答案:\n{answer}")
            
            elif user_input.startswith('search '):
                query = user_input[7:]
                results = agent.search_knowledge(query)
                if results:
                    print(f"🔍 找到 {len(results)} 条相关结果:")
                    for i, result in enumerate(results, 1):
                        print(f"\n{i}. 📖 {result['topic']}")
                        print(f"   {result['content'][:100]}...")
                        if result['source']:
                            print(f"   📎 来源: {result['source']}")
                else:
                    print("❌ 没有找到相关结果")
            
            elif user_input.startswith('analyze '):
                code = user_input[8:]
                analysis = agent.analyze_and_learn_code(code)
                if 'error' not in analysis:
                    print(f"✅ 代码分析完成!")
                    print(f"  语言: {analysis['language']}")
                    print(f"  大小: {analysis['lines']} 行")
                    print(f"  复杂度: {analysis['complexity']}")
                    print(f"  函数: {', '.join(analysis['key_functions'][:3])}")
                    if analysis.get('learned'):
                        print(f"  已学习到知识库: {analysis['knowledge_topic']}")
                else:
                    print(f"❌ 分析失败: {analysis['error']}")
            
            elif user_input == 'stats':
                stats = agent.get_learning_stats()
                print("📊 学习统计:")
                print(f"  知识条目: {stats['knowledge_count']}")
                print(f"  问答对: {stats['qa_count']}")
                print(f"  主题数量: {stats['topic_count']}")
                print(f"  最后学习: {stats.get('last_learned', '未知')}")
                print(f"  MCP工具: {stats['mcp_tools_enabled']} 个已启用")
                print(f"  Notion配置: {'✅' if stats.get('notion_configured') else '❌'}")
                print(f"  网页抓取器: {'✅ 就绪' if stats.get('web_crawler_ready') else '❌ 未就绪'}")
            
            elif user_input == 'topics':
                topics = agent.list_knowledge_topics()
                if topics:
                    print(f"📚 知识主题 ({len(topics)} 个):")
                    for topic in topics:
                        print(f"  • {topic}")
                else:
                    print("❌ 知识库为空")
            
            elif user_input == 'tools':
                tools = agent.mcp.get_available_tools()
                print("🛠️ 可用MCP工具:")
                for tool in tools:
                    status = "✅" if tool['enabled'] else "❌"
                    print(f"  {status} {tool['name']}: {tool['description']}")

            elif user_input.startswith('search_learn '):
                parts = user_input[13:].split(' ', 2)
                if len(parts) >= 1:
                    query = parts[0]
                    max_results = int(parts[1]) if len(parts) > 1 else 5
                    search_engine = parts[2] if len(parts) > 2 else 'google'
                    result = agent.search_and_learn(query, max_results, search_engine)
                    print(f"🔍 搜索学习结果: {result.get('message', '未知错误')}")
                else:
                    print("❌ 用法: search_learn <query> [max_results] [engine]")
                    print("   引擎选项: google, duckduckgo, bing")

            elif user_input.startswith('personalized_learn '):
                parts = user_input[19:].split(' ', 1)
                if len(parts) >= 1:
                    interests = [interest.strip() for interest in parts[0].split(',')]
                    max_topics = int(parts[1]) if len(parts) > 1 else 3
                    result = agent.generate_personalized_learning(interests, max_topics)
                    
                    if result['success']:
                        print(f"🎯 个性化学习完成: {result['message']}")
                        for learning in result['learning_results']:
                            print(f"   📚 {learning['interest']} -> {learning['query']}: {learning['message']}")
                    else:
                        print(f"❌ 个性化学习失败: {result.get('message', '未知错误')}")
                else:
                    print("❌ 用法: personalized_learn <兴趣1,兴趣2,兴趣3,...> [max_topics]")
                    print("   示例: personalized_learn 人工智能,机器学习,深度学习")

            else:
                print("❌ 未知命令，输入 'help' 查看帮助")
                
        except KeyboardInterrupt:
            print("\n👋 再见！")
            break
        except Exception as e:
            print(f"❌ 发生错误: {e}")

if __name__ == "__main__":
    interactive_enhanced_agent()