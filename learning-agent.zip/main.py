#!/usr/bin/env python3
"""
学习智能体 - 知识学习和问答系统
支持MCP开源软件集成
"""

import os
import json
import sqlite3
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import argparse
import sys

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('learning_agent.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class LearningAgent:
    """学习智能体核心类"""
    
    def __init__(self, db_path: str = "knowledge_base.db"):
        self.db_path = db_path
        self.initialize_database()
        self.mcp_tools = {}  # MCP工具集成
        
    def initialize_database(self):
        """初始化知识库数据库"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # 创建知识表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS knowledge (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    topic TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建问答表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS qa_pairs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    confidence REAL DEFAULT 1.0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建索引
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_knowledge_topic ON knowledge(topic)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_qa_question ON qa_pairs(question)')
            
            conn.commit()
            conn.close()
            logger.info("知识库数据库初始化完成")
            
        except Exception as e:
            logger.error(f"数据库初始化失败: {e}")
            raise
    
    def learn_knowledge(self, topic: str, content: str, source: str = None):
        """学习新知识"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO knowledge (topic, content, source)
                VALUES (?, ?, ?)
            ''', (topic, content, source))
            
            conn.commit()
            conn.close()
            logger.info(f"已学习主题: {topic}")
            return True
            
        except Exception as e:
            logger.error(f"学习知识失败: {e}")
            return False
    
    def add_qa_pair(self, question: str, answer: str, confidence: float = 1.0):
        """添加问答对"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO qa_pairs (question, answer, confidence)
                VALUES (?, ?, ?)
            ''', (question, answer, confidence))
            
            conn.commit()
            conn.close()
            logger.info(f"已添加问答对: {question[:50]}...")
            return True
            
        except Exception as e:
            logger.error(f"添加问答对失败: {e}")
            return False
    
    def search_knowledge(self, query: str, limit: int = 10) -> List[Dict]:
        """搜索相关知识"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT topic, content, source, created_at
                FROM knowledge 
                WHERE topic LIKE ? OR content LIKE ?
                ORDER BY created_at DESC
                LIMIT ?
            ''', (f'%{query}%', f'%{query}%', limit))
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'topic': row[0],
                    'content': row[1],
                    'source': row[2],
                    'created_at': row[3]
                })
            
            conn.close()
            return results
            
        except Exception as e:
            logger.error(f"搜索知识失败: {e}")
            return []
    
    def answer_question(self, question: str) -> Optional[str]:
        """回答问题"""
        try:
            # 首先在问答库中查找
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT answer, confidence
                FROM qa_pairs 
                WHERE question LIKE ?
                ORDER BY confidence DESC, created_at DESC
                LIMIT 1
            ''', (f'%{question}%',))
            
            result = cursor.fetchone()
            if result:
                conn.close()
                return result[0]
            
            # 如果没有匹配的问答对，从知识库中生成答案
            cursor.execute('''
                SELECT content 
                FROM knowledge 
                WHERE topic LIKE ? OR content LIKE ?
                ORDER BY created_at DESC
                LIMIT 3
            ''', (f'%{question}%', f'%{question}%'))
            
            knowledge = [row[0] for row in cursor.fetchall()]
            conn.close()
            
            if knowledge:
                # 简单合并相关知识作为答案
                return "\n\n".join(knowledge)
            
            return None
            
        except Exception as e:
            logger.error(f"回答问题失败: {e}")
            return None
    
    def integrate_mcp_tool(self, tool_name: str, tool_config: Dict):
        """集成MCP工具"""
        self.mcp_tools[tool_name] = tool_config
        logger.info(f"已集成MCP工具: {tool_name}")
    
    def list_knowledge_topics(self) -> List[str]:
        """列出所有知识主题"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('SELECT DISTINCT topic FROM knowledge ORDER BY topic')
            topics = [row[0] for row in cursor.fetchall()]
            
            conn.close()
            return topics
            
        except Exception as e:
            logger.error(f"列出主题失败: {e}")
            return []
    
    def export_knowledge(self, export_path: str):
        """导出知识库"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('SELECT topic, content, source, created_at FROM knowledge')
            knowledge_data = [
                {
                    'topic': row[0],
                    'content': row[1],
                    'source': row[2],
                    'created_at': row[3]
                }
                for row in cursor.fetchall()
            ]
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(knowledge_data, f, ensure_ascii=False, indent=2)
            
            conn.close()
            logger.info(f"知识库已导出到: {export_path}")
            return True
            
        except Exception as e:
            logger.error(f"导出知识库失败: {e}")
            return False

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='学习智能体 - 知识学习和问答系统')
    parser.add_argument('--learn', '-l', help='学习新知识，格式: "主题:内容"')
    parser.add_argument('--ask', '-a', help='提问问题')
    parser.add_argument('--search', '-s', help='搜索知识')
    parser.add_argument('--export', '-e', help='导出知识库到指定文件')
    parser.add_argument('--topics', '-t', action='store_true', help='列出所有知识主题')
    
    args = parser.parse_args()
    
    agent = LearningAgent()
    
    if args.learn:
        if ':' in args.learn:
            topic, content = args.learn.split(':', 1)
            agent.learn_knowledge(topic.strip(), content.strip())
        else:
            print("请使用格式: --learn '主题:内容'")
    
    elif args.ask:
        answer = agent.answer_question(args.ask)
        if answer:
            print(f"\n答案:\n{answer}")
        else:
            print("抱歉，我还没有学习过这方面的知识。")
    
    elif args.search:
        results = agent.search_knowledge(args.search)
        if results:
            print(f"\n找到 {len(results)} 条相关结果:")
            for i, result in enumerate(results, 1):
                print(f"\n{i}. 主题: {result['topic']}")
                print(f"   内容: {result['content'][:100]}...")
                if result['source']:
                    print(f"   来源: {result['source']}")
        else:
            print("没有找到相关结果。")
    
    elif args.export:
        if agent.export_knowledge(args.export):
            print(f"知识库已导出到: {args.export}")
        else:
            print("导出失败")
    
    elif args.topics:
        topics = agent.list_knowledge_topics()
        if topics:
            print(f"\n知识主题列表 ({len(topics)} 个):")
            for topic in topics:
                print(f"  - {topic}")
        else:
            print("知识库为空")
    
    else:
        # 交互模式
        print("欢迎使用学习智能体！输入 'quit' 退出，'help' 查看帮助")
        while True:
            try:
                user_input = input("\n> ").strip()
                
                if user_input.lower() in ['quit', 'exit', 'q']:
                    break
                elif user_input.lower() in ['help', '?']:
                    print("\n可用命令:")
                    print("  learn 主题:内容  - 学习新知识")
                    print("  ask 问题        - 提问问题") 
                    print("  search 关键词    - 搜索知识")
                    print("  topics          - 列出所有主题")
                    print("  quit            - 退出程序")
                elif user_input.startswith('learn '):
                    parts = user_input[6:].split(':', 1)
                    if len(parts) == 2:
                        agent.learn_knowledge(parts[0].strip(), parts[1].strip())
                        print("学习完成！")
                    else:
                        print("格式错误，请使用: learn 主题:内容")
                elif user_input.startswith('ask '):
                    question = user_input[4:]
                    answer = agent.answer_question(question)
                    if answer:
                        print(f"\n答案:\n{answer}")
                    else:
                        print("抱歉，我还没有学习过这方面的知识。")
                elif user_input.startswith('search '):
                    query = user_input[7:]
                    results = agent.search_knowledge(query)
                    if results:
                        print(f"找到 {len(results)} 条相关结果:")
                        for i, result in enumerate(results, 1):
                            print(f"\n{i}. 主题: {result['topic']}")
                            print(f"   内容: {result['content'][:100]}...")
                    else:
                        print("没有找到相关结果。")
                elif user_input == 'topics':
                    topics = agent.list_knowledge_topics()
                    if topics:
                        print(f"知识主题列表 ({len(topics)} 个):")
                        for topic in topics:
                            print(f"  - {topic}")
                    else:
                        print("知识库为空")
                else:
                    print("未知命令，输入 'help' 查看帮助")
                    
            except KeyboardInterrupt:
                print("\n再见！")
                break
            except Exception as e:
                print(f"发生错误: {e}")

if __name__ == "__main__":
    main()