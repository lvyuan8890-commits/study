#!/usr/bin/env python3
"""
学习智能体安装脚本
自动安装所需依赖和配置环境
"""

import os
import sys
import subprocess
import logging
from typing import List

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def check_python_version() -> bool:
    """检查Python版本"""
    required_version = (3, 8)
    current_version = sys.version_info[:2]
    
    if current_version >= required_version:
        logger.info(f"Python版本检查通过: {sys.version}")
        return True
    else:
        logger.error(f"需要Python {required_version[0]}.{required_version[1]} 或更高版本，当前版本: {sys.version}")
        return False

def install_requirements() -> bool:
    """安装依赖包"""
    try:
        logger.info("正在安装依赖包...")
        
        # 使用pip安装requirements.txt中的包
        result = subprocess.run([
            sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'
        ], capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.returncode == 0:
            logger.info("依赖包安装成功！")
            return True
        else:
            logger.error(f"依赖包安装失败: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"安装过程中发生错误: {e}")
        return False

def create_shortcut() -> bool:
    """创建快捷方式（Windows）"""
    try:
        if os.name == 'nt':  # Windows系统
            shortcut_content = f'''@echo off
echo 启动学习智能体...
cd /d "{os.path.dirname(__file__)}"
python enhanced_agent.py
pause
'''
            
            bat_path = os.path.join(os.path.dirname(__file__), 'start_agent.bat')
            with open(bat_path, 'w', encoding='utf-8') as f:
                f.write(shortcut_content)
            
            logger.info(f"已创建启动脚本: {bat_path}")
            return True
        else:
            logger.info("非Windows系统，跳过快捷方式创建")
            return True
            
    except Exception as e:
        logger.error(f"创建快捷方式失败: {e}")
        return False

def setup_environment() -> bool:
    """设置环境"""
    try:
        # 创建必要的目录
        directories = ['data', 'logs', 'backups']
        for directory in directories:
            dir_path = os.path.join(os.path.dirname(__file__), directory)
            os.makedirs(dir_path, exist_ok=True)
            logger.info(f"创建目录: {dir_path}")
        
        # 检查配置文件
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        if not os.path.exists(config_path):
            logger.warning("配置文件不存在，将使用默认配置")
        
        return True
        
    except Exception as e:
        logger.error(f"环境设置失败: {e}")
        return False

def main():
    """主安装函数"""
    print("=" * 50)
    print("🤖 学习智能体安装程序")
    print("=" * 50)
    
    # 检查Python版本
    if not check_python_version():
        print("\n❌ Python版本检查失败，请安装Python 3.8或更高版本")
        return False
    
    # 设置环境
    print("\n📁 设置环境...")
    if not setup_environment():
        print("❌ 环境设置失败")
        return False
    
    # 安装依赖
    print("\n📦 安装依赖包...")
    if not install_requirements():
        print("❌ 依赖包安装失败")
        return False
    
    # 创建快捷方式
    print("\n🔗 创建快捷方式...")
    if not create_shortcut():
        print("⚠️  快捷方式创建失败，但不影响主要功能")
    
    print("\n" + "=" * 50)
    print("✅ 安装完成！")
    print("\n🚀 启动方式:")
    print("  1. 直接运行: python enhanced_agent.py")
    print("  2. Windows用户可运行: start_agent.bat")
    print("\n💡 首次使用建议:")
    print("  - 运行后输入 'help' 查看所有命令")
    print("  - 尝试 'learn 人工智能:人工智能是计算机科学的一个分支'")
    print("  - 然后输入 'ask 什么是人工智能' 测试问答功能")
    print("=" * 50)
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)