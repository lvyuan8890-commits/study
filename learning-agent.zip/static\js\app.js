class LearningAgentApp {
    constructor() {
        this.initializeEventListeners();
        this.loadStats();
    }

    initializeEventListeners() {
        const sendButton = document.getElementById('sendButton');
        const userInput = document.getElementById('userInput');
        const quickButtons = document.querySelectorAll('.quick-btn');

        // 发送消息事件
        sendButton.addEventListener('click', () => this.handleUserInput());
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleUserInput();
            }
        });

        // 快速操作按钮
        quickButtons.forEach(button => {
            button.addEventListener('click', () => {
                const command = button.getAttribute('data-command');
                this.sendCommand(command);
            });
        });
    }

    async handleUserInput() {
        const input = document.getElementById('userInput');
        const message = input.value.trim();
        
        if (!message) return;

        // 添加用户消息到聊天界面
        this.addMessage(message, 'user');
        input.value = '';

        try {
            // 发送到后端API
            const response = await this.sendToBackend(message);
            
            // 添加AI回复
            this.addMessage(response.response, 'bot');
            
            // 如果是统计命令，更新统计信息
            if (message.toLowerCase().includes('统计') || message.toLowerCase().includes('stats')) {
                this.loadStats();
            }
            
        } catch (error) {
            console.error('Error:', error);
            this.addMessage('抱歉，处理您的请求时出现了错误。请稍后再试。', 'bot');
        }
    }

    async sendCommand(command) {
        const input = document.getElementById('userInput');
        input.value = command;
        this.handleUserInput();
    }

    async sendToBackend(message) {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    }

    addMessage(content, type) {
        const messagesContainer = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        if (type === 'bot') {
            messageContent.innerHTML = `<strong>学习智能体:</strong> ${this.formatMessage(content)}`;
        } else {
            messageContent.innerHTML = `<strong>您:</strong> ${this.formatMessage(content)}`;
        }
        
        messageDiv.appendChild(messageContent);
        messagesContainer.appendChild(messageDiv);
        
        // 滚动到底部
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    formatMessage(content) {
        // 简单的消息格式化
        return content
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
    }

    async loadStats() {
        const statsContainer = document.getElementById('statsContent');
        statsContainer.innerHTML = '<div class="loading">加载统计信息...</div>';

        try {
            const response = await fetch('/api/stats');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const stats = await response.json();
            
            if (stats.error) {
                statsContainer.innerHTML = `<div class="error">${stats.error}</div>`;
                return;
            }

            let statsHTML = `
                <div class="stats-item">
                    <span>学习主题:</span>
                    <strong>${stats.learned_topics || 0}</strong>
                </div>
                <div class="stats-item">
                    <span>知识条目:</span>
                    <strong>${stats.knowledge_count || 0}</strong>
                </div>
                <div class="stats-item">
                    <span>搜索次数:</span>
                    <strong>${stats.search_count || 0}</strong>
                </div>
                <div class="stats-item">
                    <span>文件处理:</span>
                    <strong>${stats.file_processed || 0}</strong>
                </div>
                <div class="stats-item">
                    <span>活跃天数:</span>
                    <strong>${stats.active_days || 0}</strong>
                </div>
            `;

            statsContainer.innerHTML = statsHTML;
            
        } catch (error) {
            console.error('Error loading stats:', error);
            statsContainer.innerHTML = '<div class="error">加载统计信息失败</div>';
        }
    }

    // 辅助方法：显示加载状态
    showLoading() {
        const messagesContainer = document.getElementById('chatMessages');
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message bot-message loading';
        loadingDiv.innerHTML = '<div class="message-content">思考中...</div>';
        messagesContainer.appendChild(loadingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        return loadingDiv;
    }

    // 辅助方法：隐藏加载状态
    hideLoading(loadingDiv) {
        if (loadingDiv && loadingDiv.parentNode) {
            loadingDiv.parentNode.removeChild(loadingDiv);
        }
    }
}

// 页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', () => {
    new LearningAgentApp();
});

// 添加一些实用的工具函数
const Utils = {
    // 防抖函数
    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // 格式化日期
    formatDate: (date) => {
        return new Date(date).toLocaleDateString('zh-CN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
};