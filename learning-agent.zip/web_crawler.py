#!/usr/bin/env python3
"""
全网信息自动抓取模块 - 支持多种来源的信息采集
"""

import logging
import requests
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import time
import re
from urllib.parse import urlparse, urljoin
import os
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class WebCrawler:
    """全网信息自动抓取器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {
            'max_depth': 2,
            'delay': 1.0,  # 请求延迟（秒）
            'timeout': 10,
            'max_pages': 50,
            'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'allowed_domains': [],
            'blacklist': ['google', 'facebook', 'twitter', 'login', 'signup']
        }
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': self.config['user_agent']
        })
        
        self.visited_urls = set()
        self.crawled_data = []
    
    def crawl_website(self, url: str, max_pages: int = None) -> List[Dict]:
        """爬取整个网站的内容"""
        try:
            max_pages = max_pages or self.config['max_pages']
            domain = urlparse(url).netloc
            
            logger.info(f"开始爬取网站: {url}")
            
            # 使用广度优先搜索爬取
            to_crawl = [{'url': url, 'depth': 0}]
            crawled = []
            
            while to_crawl and len(crawled) < max_pages:
                current = to_crawl.pop(0)
                
                if current['url'] in self.visited_urls:
                    continue
                
                if current['depth'] > self.config['max_depth']:
                    continue
                
                # 检查URL是否在黑名单中
                if any(blackword in current['url'].lower() for blackword in self.config['blacklist']):
                    continue
                
                # 获取页面内容
                page_data = self._crawl_page(current['url'], current['depth'])
                if page_data:
                    crawled.append(page_data)
                    self.crawled_data.append(page_data)
                    
                    # 提取并添加新链接
                    if current['depth'] < self.config['max_depth']:
                        new_links = self._extract_links(page_data['content'], current['url'], domain)
                        for link in new_links:
                            if link not in self.visited_urls:
                                to_crawl.append({'url': link, 'depth': current['depth'] + 1})
                
                self.visited_urls.add(current['url'])
                time.sleep(self.config['delay'])  # 礼貌延迟
            
            logger.info(f"网站爬取完成，共获取 {len(crawled)} 个页面")
            return crawled
            
        except Exception as e:
            logger.error(f"网站爬取失败: {e}")
            return []
    
    def _crawl_page(self, url: str, depth: int) -> Optional[Dict]:
        """爬取单个页面"""
        try:
            response = self.session.get(url, timeout=self.config['timeout'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # 提取标题
            title = soup.find('title')
            title_text = title.get_text().strip() if title else "无标题"
            
            # 提取主要内容
            content = self._extract_main_content(soup)
            
            # 清理内容
            cleaned_content = self._clean_content(content)
            
            # 提取元数据
            metadata = self._extract_metadata(soup)
            
            return {
                'url': url,
                'title': title_text,
                'content': cleaned_content,
                'depth': depth,
                'timestamp': datetime.now().isoformat(),
                'metadata': metadata,
                'word_count': len(cleaned_content.split())
            }
            
        except Exception as e:
            logger.warning(f"页面爬取失败 {url}: {e}")
            return None
    
    def _extract_main_content(self, soup: BeautifulSoup) -> str:
        """提取主要内容"""
        # 尝试多种内容提取策略
        content_selectors = [
            'article',
            'main',
            '.content',
            '.main-content',
            '#content',
            'div[role="main"]',
            'body'
        ]
        
        for selector in content_selectors:
            element = soup.select_one(selector)
            if element and len(element.get_text().strip()) > 100:
                return element.get_text().strip()
        
        # 如果没找到，返回整个body
        return soup.body.get_text().strip() if soup.body else ""
    
    def _clean_content(self, content: str) -> str:
        """清理内容"""
        # 移除多余空白
        content = re.sub(r'\s+', ' ', content)
        # 移除JavaScript和CSS
        content = re.sub(r'<script.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<style.*?</style>', '', content, flags=re.DOTALL)
        # 移除HTML标签
        content = re.sub(r'<[^>]+>', '', content)
        return content.strip()
    
    def _extract_metadata(self, soup: BeautifulSoup) -> Dict:
        """提取元数据"""
        metadata = {}
        
        # 提取meta描述
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc:
            metadata['description'] = meta_desc.get('content', '')
        
        # 提取关键词
        meta_keywords = soup.find('meta', attrs={'name': 'keywords'})
        if meta_keywords:
            metadata['keywords'] = meta_keywords.get('content', '')
        
        # 提取作者
        meta_author = soup.find('meta', attrs={'name': 'author'})
        if meta_author:
            metadata['author'] = meta_author.get('content', '')
        
        # 提取发布时间
        time_patterns = [
            'time[datetime]',
            '.publish-date',
            '.date',
            '[property="article:published_time"]'
        ]
        
        for pattern in time_patterns:
            element = soup.select_one(pattern)
            if element:
                metadata['publish_date'] = element.get('datetime') or element.get_text()
                break
        
        return metadata
    
    def _extract_links(self, content: str, base_url: str, domain: str) -> List[str]:
        """从内容中提取链接"""
        try:
            soup = BeautifulSoup(content, 'html.parser')
            links = []
            
            for a in soup.find_all('a', href=True):
                href = a['href']
                full_url = urljoin(base_url, href)
                
                # 只保留同域名链接
                if urlparse(full_url).netloc == domain:
                    links.append(full_url)
            
            return list(set(links))  # 去重
            
        except Exception as e:
            logger.warning(f"链接提取失败: {e}")
            return []
    
    def search_and_crawl(self, query: str, search_engine: str = 'google', max_results: int = 5) -> List[Dict]:
        """
        使用搜索引擎搜索并抓取相关内容
        
        Args:
            query: 搜索关键词
            search_engine: 搜索引擎 (google, duckduckgo, bing)
            max_results: 最大结果数量
            
        Returns:
            抓取到的页面内容列表
        """
        try:
            logger.info(f"使用 {search_engine} 搜索: {query}")
            
            # 根据搜索引擎生成搜索URL
            search_urls = {
                'google': f"https://www.google.com/search?q={query.replace(' ', '+')}&num={max_results}",
                'duckduckgo': f"https://duckduckgo.com/html/?q={query.replace(' ', '+')}",
                'bing': f"https://www.bing.com/search?q={query.replace(' ', '+')}&count={max_results}"
            }
            
            if search_engine not in search_urls:
                logger.warning(f"不支持的搜索引擎: {search_engine}, 使用默认的google")
                search_engine = 'google'
            
            # 获取搜索页面
            response = self.session.get(search_urls[search_engine], timeout=self.config['timeout'])
            response.raise_for_status()
            
            # 解析搜索结果 (简化版)
            search_results = self._parse_search_results(response.text, search_engine)
            
            # 限制结果数量
            search_results = search_results[:max_results]
            
            # 抓取每个搜索结果页面
            crawled_pages = []
            for i, result in enumerate(search_results):
                logger.info(f"抓取第 {i+1}/{len(search_results)} 个结果: {result['url']}")
                
                page_data = self._crawl_page(result['url'], 0)
                if page_data:
                    crawled_pages.append(page_data)
                    self.crawled_data.append(page_data)
                
                # 添加延迟以避免请求过于频繁
                time.sleep(self.config.get('delay', 1.0))
                
                # 如果已经达到最大页面数，提前退出
                if len(crawled_pages) >= max_results:
                    break
            
            logger.info(f"搜索爬取完成，共获取 {len(crawled_pages)} 个页面")
            return crawled_pages
            
        except Exception as e:
            logger.error(f"搜索抓取失败: {e}")
            return []
    
    def _parse_search_results(self, html_content: str, search_engine: str) -> List[Dict]:
        """解析搜索引擎结果页面"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            results = []
            
            if search_engine == 'google':
                # 解析Google搜索结果
                for result in soup.select('.tF2Cxc, .g'):
                    title_elem = result.select_one('h3')
                    link_elem = result.select_one('a')
                    snippet_elem = result.select_one('.VwiC3b, .s3v9rd')
                    
                    if title_elem and link_elem:
                        results.append({
                            'title': title_elem.get_text().strip(),
                            'url': link_elem.get('href', ''),
                            'snippet': snippet_elem.get_text().strip() if snippet_elem else ''
                        })
            
            elif search_engine == 'bing':
                # 解析Bing搜索结果
                for result in soup.select('.b_algo'):
                    title_elem = result.select_one('h2')
                    link_elem = result.select_one('a')
                    snippet_elem = result.select_one('.b_caption p')
                    
                    if title_elem and link_elem:
                        results.append({
                            'title': title_elem.get_text().strip(),
                            'url': link_elem.get('href', ''),
                            'snippet': snippet_elem.get_text().strip() if snippet_elem else ''
                        })
            
            else:  # duckduckgo or fallback
                # 解析DuckDuckGo或其他搜索结果
                for result in soup.select('.result__a'):
                    title = result.get_text().strip()
                    url = result.get('href', '')
                    if title and url:
                        results.append({
                            'title': title,
                            'url': url,
                            'snippet': ''
                        })
            
            return results
            
        except Exception as e:
            logger.error(f"解析搜索结果失败: {e}")
            return []
    
    def _web_search(self, query: str, engine: str, max_results: int) -> List[Dict]:
        """执行Web搜索"""
        try:
            if engine == 'duckduckgo':
                return self._duckduckgo_search(query, max_results)
            elif engine == 'google':
                return self._google_search(query, max_results)
            else:
                logger.warning(f"不支持的搜索引擎: {engine}")
                return []
                
        except Exception as e:
            logger.error(f"Web搜索失败: {e}")
            return []
    
    def _duckduckgo_search(self, query: str, max_results: int) -> List[Dict]:
        """DuckDuckGo搜索"""
        try:
            url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1&skip_disambig=1"
            response = self.session.get(url, timeout=self.config['timeout'])
            response.raise_for_status()
            
            data = response.json()
            results = []
            
            # 处理抽象结果
            if data.get('AbstractText'):
                results.append({
                    'title': data.get('Heading', query),
                    'url': data.get('AbstractURL', ''),
                    'snippet': data['AbstractText']
                })
            
            # 处理相关主题
            for topic in data.get('RelatedTopics', [])[:max_results]:
                if 'FirstURL' in topic and 'Text' in topic:
                    results.append({
                        'title': topic['Text'].split(' - ')[0] if ' - ' in topic['Text'] else topic['Text'],
                        'url': topic['FirstURL'],
                        'snippet': topic['Text']
                    })
            
            return results[:max_results]
            
        except Exception as e:
            logger.error(f"DuckDuckGo搜索失败: {e}")
            return []
    
    def _google_search(self, query: str, max_results: int) -> List[Dict]:
        """Google搜索（需要API密钥）"""
        # 这里需要Google Custom Search JSON API
        # 暂时返回空结果
        logger.warning("Google搜索需要API密钥配置")
        return []
    
    def export_data(self, format: str = 'json', file_path: str = None) -> bool:
        """导出爬取的数据"""
        try:
            if not self.crawled_data:
                logger.warning("没有数据可导出")
                return False
            
            if format == 'json':
                file_path = file_path or f"web_crawler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.crawled_data, f, ensure_ascii=False, indent=2)
                
            elif format == 'txt':
                file_path = file_path or f"web_crawler_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                with open(file_path, 'w', encoding='utf-8') as f:
                    for item in self.crawled_data:
                        f.write(f"标题: {item['title']}\n")
                        f.write(f"URL: {item['url']}\n")
                        f.write(f"内容: {item['content'][:500]}...\n")
                        f.write("-" * 50 + "\n\n")
            
            logger.info(f"数据已导出到: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"数据导出失败: {e}")
            return False

def main():
    """测试网页抓取"""
    crawler = WebCrawler()
    
    # 示例：爬取网站
    # results = crawler.crawl_website("https://example.com", max_pages=5)
    # print(f"爬取了 {len(results)} 个页面")
    
    # 示例：搜索爬取
    # results = crawler.search_and_crawl("Python编程", max_results=3)
    # print(f"搜索爬取了 {len(results)} 个页面")
    
    print("✅ 网页抓取器初始化完成")
    print("可用方法:")
    print("  - crawl_website(url, max_pages)")
    print("  - search_and_crawl(query, max_results)")
    print("  - export_data(format, file_path)")

if __name__ == "__main__":
    main()