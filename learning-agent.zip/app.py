#!/usr/bin/env python3
"""
学习智能体Web应用 - Flask封装版本
"""

from flask import Flask, render_template, request, jsonify, session
import json
import sqlite3
import logging
from datetime import datetime
from functools import wraps

# 导入您的学习智能体模块
try:
    from enhanced_agent import EnhancedLearningAgent
    from mcp_integration import MCPIntegration
    from notion_integration import NotionIntegration
    from web_crawler import WebCrawler
    AGENT_AVAILABLE = True
except ImportError as e:
    print(f"导入模块失败: {e}")
    AGENT_AVAILABLE = False

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'
app.config['JSON_AS_ASCII'] = False

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 全局智能体实例
agent = None

def init_agent():
    """初始化学习智能体"""
    global agent
    if AGENT_AVAILABLE:
        try:
            agent = EnhancedLearningAgent()
            logger.info("学习智能体初始化成功")
        except Exception as e:
            logger.error(f"智能体初始化失败: {e}")
            agent = None

# 初始化智能体
init_agent()

def require_agent(f):
    """装饰器：要求智能体可用"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not agent:
            return jsonify({'error': '学习智能体未初始化或不可用'}), 503
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    """主页"""
    return render_template('index.html', agent_available=AGENT_AVAILABLE)

@app.route('/api/learn', methods=['POST'])
@require_agent
def api_learn():
    """API: 学习新知识"""
    try:
        data = request.get_json()
        topic = data.get('topic', '')
        content = data.get('content', '')
        
        if not topic or not content:
            return jsonify({'error': '主题和内容不能为空'}), 400
        
        success = agent.learn_knowledge(topic, content)
        
        return jsonify({
            'success': success,
            'message': '学习成功' if success else '学习失败'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ask', methods=['POST'])
@require_agent
def api_ask():
    """API: 提问问题"""
    try:
        data = request.get_json()
        question = data.get('question', '')
        
        if not question:
            return jsonify({'error': '问题不能为空'}), 400
        
        answer = agent.enhanced_answer_question(question)
        
        return jsonify({
            'answer': answer,
            'question': question
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search', methods=['POST'])
@require_agent
def api_search():
    """API: 搜索知识"""
    try:
        data = request.get_json()
        query = data.get('query', '')
        
        if not query:
            return jsonify({'error': '搜索关键词不能为空'}), 400
        
        results = agent.search_knowledge(query)
        
        return jsonify({
            'results': results,
            'count': len(results)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search_learn', methods=['POST'])
@require_agent
def api_search_learn():
    """API: 搜索并学习网络内容"""
    try:
        data = request.get_json()
        query = data.get('query', '')
        max_results = data.get('max_results', 5)
        engine = data.get('engine', 'google')
        
        if not query:
            return jsonify({'error': '搜索查询不能为空'}), 400
        
        result = agent.search_and_learn(query, max_results, engine)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/personalized_learn', methods=['POST'])
@require_agent
def api_personalized_learn():
    """API: 个性化学习内容生成"""
    try:
        data = request.get_json()
        interests = data.get('interests', [])
        max_topics = data.get('max_topics', 3)
        
        if not interests:
            return jsonify({'error': '兴趣列表不能为空'}), 400
        
        result = agent.generate_personalized_learning(interests, max_topics)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats')
@require_agent
def api_stats():
    """API: 获取统计信息"""
    try:
        stats = agent.get_learning_stats()
        return jsonify(stats)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/topics')
@require_agent
def api_topics():
    """API: 获取主题列表"""
    try:
        topics = agent.list_knowledge_topics()
        return jsonify({'topics': topics, 'count': len(topics)})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health')
def api_health():
    """API: 健康检查"""
    return jsonify({
        'status': 'healthy',
        'agent_available': AGENT_AVAILABLE,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/chat', methods=['POST'])
@require_agent
def api_chat():
    """API: 聊天对话接口"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        
        if not message:
            return jsonify({'error': '消息不能为空'}), 400
        
        # 处理不同类型的命令
        response = agent.process_command(message)
        
        return jsonify({
            'response': response,
            'success': True
        })
    
    except Exception as e:
        logger.error(f"聊天处理错误: {e}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': '接口不存在'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': '服务器内部错误'}), 500

if __name__ == '__main__':
    print("🚀 学习智能体Web服务启动中...")
    print(f"📊 智能体状态: {'可用' if AGENT_AVAILABLE else '不可用'}")
    app.run(host='0.0.0.0', port=5000, debug=True)